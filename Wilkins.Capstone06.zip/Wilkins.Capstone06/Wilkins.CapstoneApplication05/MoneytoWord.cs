﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wilkins.CapstoneApplication05
{
    public partial class MoneytoWord : Form
    {
        public MoneytoWord()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            createANewNumber(txtInput.Text, "U.S. Dollars");
        }
        public void createANewNumber(String theNumber, String currencyType)
        {
            Conversion newNumber = new Conversion(theNumber, currencyType);

            if (newNumber.get_convertedNumber().Length == 0)
            {
                lblOutputConvertedNumber.Text = newNumber.invalidInputDisplay();
            }
            else
            {
                lblOutputConvertedNumber.Text = newNumber.get_convertedNumber();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExitApp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnClearInput_Click(object sender, EventArgs e)
        {
            txtInput.Text = String.Empty;
            lblOutputConvertedNumber.Text = "Your Number When Converted Will Display Here.";
        }

        private void txtInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '$' || e.KeyChar == '\b' || e.KeyChar == '.' || e.KeyChar == ',')
            {
                e.Handled = false;
            }
            else if (e.KeyChar > '9' || e.KeyChar < '0')
            {
                e.Handled = true;
            }

            if (txtInput.Text.Length > 16)
            {
                e.Handled = true;
            }

            if (restrictNumbersAfterDecimal())
            {
                e.Handled = true;
            }
        }

        public bool restrictNumbersAfterDecimal()
        {
            if (txtInput.Text.Contains('.'))
            {
                if ((txtInput.Text.Substring(txtInput.Text.LastIndexOf('.')).Length >= 3))
                    return true;
            }
            return false;
        }

        private void lbl_Input_Click(object sender, EventArgs e)
        {

        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
