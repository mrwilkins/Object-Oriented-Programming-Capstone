﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wilkins.CapstoneDesign03
{
    public class Validation
    {
        public Validation() { }

        public bool checkIfIntegerIsValid(String a)
        {
            // Check Return True if Passed String is a Valid Integer
        }

        public bool checkIfDoubleIsValid(String a)
        {
            // Check Return True if Passed String is a Valid Double
        }

        public void checkForNegatives()
        {
            // Scan Character by Character
            // If There is a Hyphen Return False
        }

        public void checkForBillion()
        {
            // Scan Character by Character
            // If it Exceeds a Billion Return False
        }

        public bool checkForIllegalCharacters()
        {
            // Scan Character by Character
            // If There is a Special Character That isn't a Period or a Slash Return False
        }

        public String removeIllegalCharacters()
        {
            // If the Past String Contains Illegal Characters Remove them from the String
        }

        public bool numberLengthValidator(String input)
        {
            // If Number is Greater than 1 Billion Return False
            // If Number is less than 0 Return False
            // Return True if Number is Between These two Values
        }
    }
}