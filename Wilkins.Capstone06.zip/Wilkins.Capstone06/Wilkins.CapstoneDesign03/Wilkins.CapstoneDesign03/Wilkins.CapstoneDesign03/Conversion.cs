﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wilkins.CapstoneDesign03
{
    public class Conversion
    {
        public int S;

        public int Output;

        public void Convert(String s)
        {
            // For Loop to Scan Character by Character
            // The Decimal Place Informs the Conversion (The Third Decimal Place Equals "Hundreds")
            // Convert Number to Letter or Word Version
            // Output += Number + "Thousand"/Ones/Hundreds/Tens.
        }
        private string convertFromFractionToDecimal()
        {
            // Divide Numerator by Denominator
            // Return to Convert
        }
        private int getNumberofDigits()
        {
            // Number of Digits Equals String.Length
            // Check for Decimals
            // If There are Decimals, Number of Digits -= 3
        }

        public bool teenIdentifier(String number)
        {
            // If Passed Number is a Teen Return True
        }

        public bool onesIdentifier(String number)
        {
            // If Passed Number is a Ones Return True
        }

        public bool hundredsIdentifier(String number)
        {
            // If Passed Number is a Hundreds Return True
        }

        public bool tensIdentifier(String number)
        {
            // If Passed Number is a Tens Return True
        }
    }
}